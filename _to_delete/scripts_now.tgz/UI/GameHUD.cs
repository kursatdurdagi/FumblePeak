using System.Linq;
using Mirror;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UIElements;

namespace FumblePeak
{
    /// <summary>
    /// Oyun içi arayüz (UI Toolkit + NextLocalization). GDD gereği can/stamina barı yok:
    /// sadece kim hangi uzvu yönetiyor, bildirimler ve duraklat menüsü.
    /// </summary>
    [RequireComponent(typeof(UIDocument))]
    public class GameHUD : MonoBehaviour
    {
        VisualElement root, roster, toast, summit, pause, limbPanel, lobbyRow;
        Label toastText, controls, lobbyCode, lobbyLabel, pauseHint;
        Button btnInvite, btnLobby;
        IVisualElementScheduledItem toastHide;
        UILocalizer loc;
        bool paused, single;
        int lastPanelHash = -2;
        readonly VisualElement[] limbCards = new VisualElement[4];
        readonly Label[] limbNames = new Label[4];
        readonly Label[] limbStates = new Label[4];
        static readonly string[] LimbKeys = { "Q", "E", "A", "D" };

        // ---- Kısa eğitim (ilk oyunda) ----
        VisualElement tutorial;
        Label tutorialText;
        int tutStep = -1;
        float tutStartY, tutTimer;
        const string TutKey = "fp_tutorial_done";

        void OnEnable()
        {
            L.EnsureInit();
            root = GetComponent<UIDocument>().rootVisualElement;
            root.pickingMode = PickingMode.Ignore;
            root.Q("hud").pickingMode = PickingMode.Ignore;
            roster = root.Q("roster");
            toast = root.Q("toast");
            toastText = root.Q<Label>("toast-text");
            summit = root.Q("summit");
            pause = root.Q("pause");
            controls = root.Q<Label>("controls");
            lobbyCode = root.Q<Label>("lobby-code");
            lobbyLabel = root.Q<Label>("lobby-label");
            lobbyRow = root.Q("lobby-row");
            pauseHint = root.Q<Label>("pause-hint");
            btnInvite = root.Q<Button>("btn-invite");
            btnLobby = root.Q<Button>("btn-lobby");
            limbPanel = root.Q("limb-panel");
            single = FumbleNetworkManager.IsSinglePlayer;

            loc = new UILocalizer(root);
            loc.Changed += RefreshTexts;

            root.Q<Button>("btn-resume").clicked += () => SetPaused(false);
            btnInvite.clicked += () => SteamLobby.Instance?.InviteFriends();
            root.Q<Button>("btn-copy").clicked += () => { GUIUtility.systemCopyBuffer = lobbyCode.text; ShowToast(L.T("lobby.copied")); };
            root.Q<Button>("btn-respawn").clicked += () => { FumblePlayer.Local?.RequestRespawn(); SetPaused(false); };
            btnLobby.clicked += ReturnToLobby;
            root.Q<Button>("btn-leave").clicked += Leave;

            foreach (var l in new[] { roster, toast, summit, controls, limbPanel }) l.pickingMode = PickingMode.Ignore;
            toast.Query<VisualElement>().ForEach(e => e.pickingMode = PickingMode.Ignore);
            summit.Query<VisualElement>().ForEach(e => e.pickingMode = PickingMode.Ignore);

            BuildLimbPanel();
            tutorial = root.Q("tutorial");
            tutorialText = root.Q<Label>("tutorial-text");
            tutorial.pickingMode = PickingMode.Ignore;
            tutorialText.pickingMode = PickingMode.Ignore;
            if (PlayerPrefs.GetInt(TutKey, 0) == 0) root.schedule.Execute(() => SetTutorial(0)).StartingIn(2500);
            RefreshTexts();

            FumblePlayer.RosterChanged += RebuildRoster;
            FumblePlayer.PlayerJoined += OnJoined;
            FumblePlayer.PlayerLeft += OnLeft;
            ClimberBody.OnRespawned += OnRespawned;
            ClimberBody.OnCheckpointReached += OnCheckpoint;
            ClimberBody.OnSummitReached += OnSummit;
            ClimberBody.OnLimbGaveUp += OnGaveUp;

            root.schedule.Execute(() => controls.AddToClassList("controls--faded")).StartingIn(14000);
            root.schedule.Execute(RebuildRoster).StartingIn(300);
            ShowToast(single ? L.T("hud.biome1") + " · " + L.T("msg.octopus") : L.T("hud.biome1"), 3f);
        }

        void OnDisable()
        {
            loc?.Dispose();
            FumblePlayer.RosterChanged -= RebuildRoster;
            FumblePlayer.PlayerJoined -= OnJoined;
            FumblePlayer.PlayerLeft -= OnLeft;
            ClimberBody.OnRespawned -= OnRespawned;
            ClimberBody.OnCheckpointReached -= OnCheckpoint;
            ClimberBody.OnSummitReached -= OnSummit;
            ClimberBody.OnLimbGaveUp -= OnGaveUp;
            FumblePlayer.InputBlocked = false;
            Time.timeScale = 1f;
        }

        void RefreshTexts()
        {
            controls.text = L.T("hud.controls", single ? L.T("hud.esc_pause") : L.T("hud.esc_menu"));
            pauseHint.text = single ? L.T("hud.paused_single") : L.T("hud.paused_coop");
            if (tutStep >= 0 && tutStep <= 2) tutorialText.text = L.T("tut." + (tutStep + 1));
            for (int i = 0; i < 4; i++) limbNames[i].text = LimbUtil.Name(i);
            lastPanelHash = -2;
            RebuildRoster();
        }

        void Update()
        {
            var kb = Keyboard.current;
            var pad = Gamepad.current;
            if ((kb != null && kb.escapeKey.wasPressedThisFrame) || (pad != null && pad.startButton.wasPressedThisFrame))
                SetPaused(!paused);
            if (kb != null && kb.hKey.wasPressedThisFrame) controls.ToggleInClassList("controls--faded");
            UpdateLimbPanel();
            UpdateTutorial();
        }

        void SetTutorial(int step)
        {
            tutStep = step;
            tutTimer = 0f;
            if (step < 0 || step > 2) { tutorial.RemoveFromClassList("tutorial--show"); return; }
            tutorialText.text = L.T("tut." + (step + 1));
            tutorial.AddToClassList("tutorial--show");
            if (step == 0 && ClimberBody.Instance != null) tutStartY = ClimberBody.Instance.TorsoPos.y;
        }

        void UpdateTutorial()
        {
            if (tutStep < 0) return;
            var body = ClimberBody.Instance;
            var me = FumblePlayer.Local;
            if (body == null || me == null) return;
            tutTimer += Time.unscaledDeltaTime;
            bool anyMineGrabbed = false;
            for (int i = 0; i < 4; i++) if (LimbUtil.Has(me.limbMask, i) && body.IsGrabbing(i)) anyMineGrabbed = true;
            if (tutStep == 0 && anyMineGrabbed) SetTutorial(1);
            else if (tutStep == 1 && body.TorsoPos.y > tutStartY + 1.2f) SetTutorial(2);
            else if (tutStep == 2 && tutTimer > 5f)
            {
                SetTutorial(-1);
                PlayerPrefs.SetInt(TutKey, 1);
                PlayerPrefs.Save();
            }
        }

        // ---------------- Duraklat ----------------
        void SetPaused(bool p)
        {
            paused = p;
            FumblePlayer.InputBlocked = p;
            pause.EnableInClassList("pause--hidden", !p);
            if (single)
            {
                Time.timeScale = p ? 0f : 1f; // tek oyuncuda gerçek duraklatma
                lobbyRow.style.display = DisplayStyle.None;
                btnInvite.style.display = DisplayStyle.None;
                btnLobby.style.display = DisplayStyle.None;
                return;
            }
            if (!p) return;

            var steam = SteamLobby.Instance;
            bool inLobby = steam != null && steam.InLobby;
            btnInvite.style.display = inLobby ? DisplayStyle.Flex : DisplayStyle.None;
            btnLobby.style.display = NetworkServer.active ? DisplayStyle.Flex : DisplayStyle.None;
            lobbyRow.style.display = DisplayStyle.Flex;
            var nm = FumbleNetworkManager.Instance;
            if (inLobby) { lobbyLabel.text = L.T("lobby.code"); lobbyCode.text = steam.LobbyCode; }
            else if (NetworkServer.active) { lobbyLabel.text = L.T("hud.address", nm.LocalPort); lobbyCode.text = LocalIp(); }
            else { lobbyLabel.text = L.T("hud.connected"); lobbyCode.text = nm.networkAddress; }
        }

        void Leave()
        {
            FumblePlayer.InputBlocked = true;
            Time.timeScale = 1f;
            SceneFader.Get().FadeOut(0.4f, () => FumbleNetworkManager.Instance.Leave(), "");
        }

        void ReturnToLobby()
        {
            if (!NetworkServer.active) return;
            FumblePlayer.InputBlocked = true;
            SceneFader.Get().FadeOut(0.4f, () => FumbleNetworkManager.Instance.ReturnToLobby(), "");
        }

        // ---------------- Oyuncu listesi ----------------
        void RebuildRoster()
        {
            if (roster == null) return;
            roster.Clear();
            if (single) return;
            foreach (var p in FumblePlayer.All.Where(x => x != null).OrderBy(x => x.slot))
            {
                var item = new VisualElement { pickingMode = PickingMode.Ignore };
                item.AddToClassList("roster-item");
                if (p.isLocalPlayer) item.AddToClassList("roster-item--local");
                var dot = new VisualElement { pickingMode = PickingMode.Ignore };
                dot.AddToClassList("roster-item__dot");
                dot.style.backgroundColor = p.Color;
                item.Add(dot);
                var name = new Label(p.playerName + (p.isLocalPlayer ? " " + L.T("lobby.you") : "")) { pickingMode = PickingMode.Ignore };
                name.AddToClassList("roster-item__name");
                item.Add(name);
                for (int i = 0; i < 4; i++)
                {
                    if (!LimbUtil.Has(p.limbMask, i)) continue;
                    var chip = new Label(LimbUtil.Name(i)) { pickingMode = PickingMode.Ignore };
                    chip.AddToClassList("limb-chip");
                    if (p.ActiveLimb == i && CountBits(p.limbMask) > 1) chip.AddToClassList("limb-chip--active");
                    item.Add(chip);
                }
                roster.Add(item);
            }
        }

        // ---------------- Uzuv paneli ----------------
        void BuildLimbPanel()
        {
            limbPanel.Clear();
            for (int i = 0; i < 4; i++)
            {
                var card = new VisualElement { pickingMode = PickingMode.Ignore };
                card.AddToClassList("limb-card");
                var key = new Label(LimbKeys[i]) { pickingMode = PickingMode.Ignore };
                key.AddToClassList("limb-card__key");
                var col = new VisualElement { pickingMode = PickingMode.Ignore };
                var name = new Label(LimbUtil.Name(i)) { pickingMode = PickingMode.Ignore };
                name.AddToClassList("limb-card__name");
                var state = new Label("") { pickingMode = PickingMode.Ignore };
                state.AddToClassList("limb-card__state");
                col.Add(name); col.Add(state);
                card.Add(key); card.Add(col);
                limbPanel.Add(card);
                limbCards[i] = card;
                limbNames[i] = name;
                limbStates[i] = state;
            }
        }

        void UpdateLimbPanel()
        {
            var me = FumblePlayer.Local;
            var body = ClimberBody.Instance;
            bool show = me != null && body != null && CountBits(me.limbMask) > 1;
            int hash = -1;
            if (show)
            {
                hash = me.limbMask | (me.ActiveLimb << 4);
                for (int i = 0; i < 4; i++)
                {
                    if (body.IsGrabbing(i)) hash |= 1 << (8 + i);
                    if (body.IsFist(i)) hash |= 1 << (12 + i);
                }
            }
            if (hash == lastPanelHash) return; // değişmediyse UI'a dokunma
            lastPanelHash = hash;

            limbPanel.style.display = show ? DisplayStyle.Flex : DisplayStyle.None;
            if (!show) return;
            for (int i = 0; i < 4; i++)
            {
                bool mine = LimbUtil.Has(me.limbMask, i);
                limbCards[i].style.display = mine ? DisplayStyle.Flex : DisplayStyle.None;
                if (!mine) continue;
                limbCards[i].EnableInClassList("limb-card--active", me.ActiveLimb == i);
                bool grab = body.IsGrabbing(i), fist = body.IsFist(i);
                limbStates[i].text = grab ? L.T("hud.state_grab") : fist ? L.T("hud.state_fist") : L.T("hud.state_free");
                limbStates[i].EnableInClassList("limb-card__state--grab", grab);
                limbStates[i].EnableInClassList("limb-card__state--fist", fist);
            }
        }

        static int CountBits(byte b) { int c = 0; while (b != 0) { c += b & 1; b >>= 1; } return c; }

        // ---------------- Bildirimler ----------------
        void ShowToast(string text, float seconds = 2f)
        {
            toastText.text = text;
            toast.AddToClassList("toast--show");
            toastHide?.Pause();
            toastHide = root.schedule.Execute(() => toast.RemoveFromClassList("toast--show")).StartingIn((long)(seconds * 1000));
        }

        void OnJoined(string name) => ShowToast(L.T("lobby.joined", name), 2.5f);
        void OnLeft(string name) => ShowToast(L.T("lobby.left", name), 2.5f);

        void OnRespawned(string reason)
        {
            SceneFader.Get().Flash(reason == "manual" ? "" : "AAAAAaaaaa...", 0.45f);
            ShowToast(L.T("hud.respawned"), 2.5f);
        }

        void OnCheckpoint() => ShowToast(L.T("hud.camp"), 2.5f);

        void OnGaveUp(int limb)
        {
            var owner = FumblePlayer.OwnerOf(limb);
            var text = L.T("hud.gave_up", LimbUtil.Name(limb));
            if (owner != null && !single) text += $" ({owner.playerName})";
            ShowToast(text, 1.8f);
        }

        void OnSummit()
        {
            summit.RemoveFromClassList("summit--hidden");
            root.schedule.Execute(() => summit.AddToClassList("summit--hidden")).StartingIn(7000);
        }

        static string cachedIp;
        static string LocalIp()
        {
            if (cachedIp != null) return cachedIp;
            try
            {
                var ip = System.Net.Dns.GetHostEntry(System.Net.Dns.GetHostName()).AddressList
                    .FirstOrDefault(a => a.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork && !System.Net.IPAddress.IsLoopback(a));
                cachedIp = ip != null ? ip.ToString() : "127.0.0.1";
            }
            catch { cachedIp = "127.0.0.1"; }
            return cachedIp;
        }
    }
}
